pref("extensions.jid1-5kBR1ECLydLNug@jetpack._ryski", "_");
